// Event listener for scroll
document.getElementById('startButton').addEventListener('click', () => {
  browser.tabs.query({ active: true, currentWindow: true }, function(tabs) {
    browser.tabs.sendMessage(tabs[0].id, { action: "button1Click" });
  });
});

// Event listener for stop
document.getElementById('stopButton').addEventListener('click', () => {
  browser.tabs.query({ active: true, currentWindow: true }, function(tabs) {
    browser.tabs.sendMessage(tabs[0].id, { action: "button2Click" });
  });
});

// Event listener for next
document.getElementById('nextButton').addEventListener('click', () => {
  browser.tabs.query({ active: true, currentWindow: true }, function(tabs) {
    browser.tabs.sendMessage(tabs[0].id, { action: "button3Click" });
  });
});
